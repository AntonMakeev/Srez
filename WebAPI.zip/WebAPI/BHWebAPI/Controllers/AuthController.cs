﻿using BHWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace BHWebAPI.Controllers
{
    [RoutePrefix("api/Auth")]
    public class AuthController : ApiController
    {

        

        [HttpPost]
        [Route("{username}/{password}")]
        public IHttpActionResult AuthenticateUser(string username, string password)
        {
            // Validate user credentials and retrieve user object from database
            User user = ValidateUserCredentials(username, password);

            if (user != null)
            {

                return Ok(new
                {
                    id = user.IDUser
                });
            }
            else
            {
                // Return 401 Unauthorized if user credentials are invalid
                return Unauthorized();
            }
        }
        ClassWorkEntities entities = new ClassWorkEntities();
        private User ValidateUserCredentials(string username, string password)
        {
            // TODO: Implement user authentication logic here
            User user = entities.User.FirstOrDefault(x => x.LoginUser == username && x.PasswordUser == password);
            if (user == null)
                return null;
            else return user;
        }
    }
}
