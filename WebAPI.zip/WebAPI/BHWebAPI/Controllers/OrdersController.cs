﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Http;
using BHWebAPI.Models;

namespace BHWebAPI.Controllers
{
    public class OrdersController : ApiController
    {
        private ClassWorkEntities db = new ClassWorkEntities();

        [Route("api/ServicesInOrder/{idorder}")]
        public IHttpActionResult ProductsInOrder(int orderid)
        {
            return Ok(db.getServicesOrder(orderid).ToList());
        }

        [Route("api/getServicesInOrder/{idorder}")]
        public IHttpActionResult getServicesInOrder(int orderid)
        {
            return Ok(db.getServicesOrder(orderid).ToList());
        }

        [Route("api/getOrderByUser/{iduser}")]
        public IHttpActionResult getOrderByUser(int userid)
        {
            return Ok(db.getOrderByUser(userid).ToList());
        }

        [HttpPost]
        [Route("api/AddOrder/{iduser}", Name = "AddOrder")]
        public IHttpActionResult AddOrder(int clientid)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            Random rand = new Random();
            int verifingcode = rand.Next(100, 999);
            db.AddOrder(clientid);
            Order or = db.Order.OrderByDescending(x => x.IDOrder).ToList()[0];
            int id = or.IDOrder;
            return Ok(new
            {
                orderid = id
            });
        }

        [HttpPost]
        [Route("api/AddServiceOrder/{idorder}/{idservice}", Name = "AddServiceOrder")]
        public IHttpActionResult AddProductInOrder(int orderid, int productid)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            db.AddServiceOrder(productid, orderid);
            return Ok();
        }

        [HttpPost]
        [Route("api/DeleteServiceOrder/{idorder}/{idservice}", Name = "DeleteServiceOrder")]
        public IHttpActionResult deleteServiceInOrder(int orderid, int productid)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            db.DeleteServiceOrder(productid, orderid);
            return Ok();
        }

        [HttpPost]
        [Route("api/DeleteOrder/{idorder}", Name = "DeleteOrder")]
        public IHttpActionResult deleteOrder(int orderid)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            db.DeleteOrder(orderid);
            return Ok();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
